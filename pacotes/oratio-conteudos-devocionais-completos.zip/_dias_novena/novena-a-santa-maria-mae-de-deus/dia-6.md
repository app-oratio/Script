---
title: Dia 6 — Novena à Santa Maria, Mãe de Deus
devotion: novena-a-santa-maria-mae-de-deus
day: 6
description: Bendita sejais, ó Virgem Maria. trouxestes no ventre quem fez o universo; Vós destes a vida a quem nos criou e virgem sereis para sempre, ó Maria!
permalink: /novenas/novena-a-santa-maria-mae-de-deus/dia-6/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 6
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-invocacao-a-santissima-virgem
    label: Invocação à Santíssima Virgem
    prayer: À vossa proteção nos acolhemos, Santa Mãe de Deus. Não desprezeis as nossas súplicas nas nossas necessidades, mas livrai-nos de todos os perigos, ó Virgem gloriosa e bendita. Amém
    language_toggle: false
  - id: oracao-003-oracao-inicial
    label: Oração Inicial
    prayer: 'Oremos: Deus, que enviastes do Céu o vosso Filho, palavra da salvação e pão da vida, ao seio da Santíssima Virgem, concedei que, a seu exemplo, recebamos a Cristo, conservando no coração as suas palavras e celebrando na fé os seus mistérios da salvação. Por Nosso Senhor Jesus Cristo, vosso Filho, que é Deus convosco na unidade do Espírito Santo. Amém.'
    language_toggle: false
  - id: oracao-004-oracao
    label: Oração
    prayer: |-
      Bendita sejais, ó Virgem Maria.
      trouxestes no ventre quem fez o universo;
      Vós destes a vida a quem nos criou
      e virgem sereis para sempre, ó Maria!
      Maria, alegra-te, ó cheia de graça,
      o Senhor é contigo.

      Raiz judaica floresce,
      a virgem mãe dá à luz.
      Maria ao mundo oferece
      Quem vem salvá-lo: Jesus.

      No manto azul agasalha
      e envolve o Filho de Deus.
      Reclina em berço de palha
      quem com seu Pai fez os céus.

      Ao Pai e ao Espírito unido,
      Filho de Deus, luz da luz.
      Por virgem mãe concedido,


      Cristo, nascido da Virgem Maria, rei pacífico, vosso reino é justiça e paz;
      – dai-nos a graça de seguirmos o caminho da paz. R.
      R. Filho da Virgem Maria, tende piedade de nós!
    language_toggle: false
  - id: oracao-005-oracao
    label: Oração
    prayer: Virgem Mãe de Deus,  em vosso seio Se fez homem Aquele que não cabe em todo o universo. Salve, Santa Mãe, que destes à luz o Rei, que governa o céu e a terra pelos séculos dos séculos. Bendita seja a Virgem Maria, que trouxe em seu ventre o Filho de Deus Pai. Amém
    language_toggle: false
  - id: oracao-006-oracao-final
    label: Oração Final
    prayer: 'Oremos: Concedei, Senhor, que, assim como a Virgem Santa Maria concebeu em seu Espírito, antes de conceber em seu ventre, o seu Filho descido do Céu, também nós, tendo-O recebido na fé, O manifestemos com obras dignas de santidade. Ele que é Deus convosco na unidade do Espírito Santo. Amém.'
    language_toggle: false
  - id: oracao-007-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
theme: Oração
---
