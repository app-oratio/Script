---
title: Intenção para o vigésimo sexto dia — Mês com o Sagrado Coração de Jesus
devotion: mes-com-o-sagrado-coracao-de-jesus
day: 26
description: Oremos por aqueles a quem Deus confiou o cuidado da nossa alma.
permalink: /devocoes-mensais/mes-com-o-sagrado-coracao-de-jesus/dia-26/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 26
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-invocacao-do-espirito-santo
    label: Invocação do Espírito Santo
    prayer: |-
      Vinde, Espírito Santo, enchei os corações dos vossos fiéis e acendei neles o fogo de vosso amor.
      V. – Enviai o vosso Espírito e tudo será criado.
      R. – E renovareis a face da terra.

      OREMOS. Deus, que esclarecestes os corações dos vossos fiéis com as luzes do Espírito Santo, concedei-nos por esse mesmo Espírito conhecer e amar o bem, e gozar sempre de suas divinas consolações. Por Jesus Cristo Nosso Senhor. Amém
    prayer-latin: |-
      Veni, Sancte Spíritus, reple tuórum corda fidélium, et tui amóris in eis ignem accénde.
      V. – Emitte Spíritum tuum et creabuntur,
      R. – Et renovábis fáciem terra.

      ÓREMUS. Deus, qui corda fidélium Sancti Spiritus ilustratióne docuisti: da nóbis in eódem Spíritu recta sápere, et de ejus semper consolatióne gaudére. Per Christum Dóminum nostrum. Amen
    language_toggle: true
  - id: oracao-003-oracao-inicial
    label: Oração Inicial
    prayer: Senhor Jesus Cristo, unindo-me à divina intenção com que na terra pelo vosso Coração Sacratíssimo rendestes louvores a Deus e ainda agora os rendeis de continuo e em todo o mundo no Santíssimo Sacramento da Eucaristia até a consumação dos séculos, eu vos ofereço por este dia inteiro, sem exceção de um instante, à imitação do Sagrado Coração da Bem-aventurada Maria sempre Virgem Imaculada, todas as minhas intenções e pensamentos, todos os meus afetos e desejos, todas as minhas obras e palavras. Amém.
    language_toggle: false
- id: secao-02-intencao-para-o-vigesimo-sexto-dia
  title: Intenção para o vigésimo sexto dia
  prayers:
  - id: oracao-004-pai-nosso
    common_prayer: pai-nosso
    language_toggle: true
    prayer-latin: Pater Noster, qui es in cælis, sanctificetur nomen tuum. Adveniat regnum tuum. Fiat voluntas tua, sicut in cælo et in terra. Panem nostrum quotidianum da nobis hodie, et dimitte nobis debita nostra sicut et nos dimittimus debitoribus nostris. Et ne nos inducas in tentationem, sed libera nos a malo. Amen.
  - id: oracao-005-ave-maria
    common_prayer: ave-maria
    language_toggle: true
    prayer-latin: Ave Maria, gratia plena, Dominus tecum. Benedicta tu in mulieribus, et benedictus fructus ventris tui, Iesus. Sancta Maria, Mater Dei, ora pro nobis peccatoribus, nunc, et in hora mortis nostræ. Amen.
  - id: oracao-006-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: true
    prayer-latin: Gloria Patri, et Filio, et Spiritui Sancto. Sicut erat in principio, et nunc, et semper, et in sæcula sæculorum. Amen.
  - id: oracao-007-jaculatoria
    label: Jaculatória
    prayer: Coração de Jesus, que tanto nos amais, fazei que vos amemos cada dia mais
    language_toggle: false
  - id: oracao-008-exemplo
    label: Exemplo
    prayer: "No ano de 1884, um seminarista de uma diocese da Áustria dirigia-se ao órgão da Liga do Apostolado para fazer publica a sua ação de graças por três mercês alcançadas do Sagrado Coração: \n\n1ª — No meio de seus estudos teológicos foi atingido pela lei militar e logo considerado valido para o serviço ativo. Com essa perspetiva de três anos de vida de quartel, recorre ao Coração de Jesus, e confia-lhe sua pessoa e sua vocação. Alguns meses mais tarde, realiza-se a segunda inspeção, cuja sentença é definitiva. Qual não foi então a sua alegria, ao ouvir esta decisão: Inapto para o serviço militar!\n\n2ª — Uma demasiada aplicação aos estudos lhe abalou a saúde, ao ponto de que o medico lhe mandou interrompê-los, durante alguns anos talvez. Cheio de confiança nas promessas do Divino Mestre invocou o seu Coração compassivo, e, contra as previsões humanas, recobra em pouco tempo todas as suas forças.\n\n3º — Uma terceira provação lhe sobrevém: sua família empobrece e não pode mais pagar\
      \ a sua pensão; ele pede aos superiores um abatimento, ou, ao menos uma espera, que a principio não lhe é concedida. Não desanima, e redobra de orações invocando o Sagrado Coração com inteiro abandono à sua providencia paternal. Sua confiança perseverante não é frustrada: algum tempo depois, sem nova diligencia de sua parte, lhe anunciam que terá de pagar só uma pequena parte da pensão.\n\nNão sabendo exprimir quanto se sente agradecido, o jovem espera o momento em que, revestido do sacerdócio, o possa mostrar, dedicando-se a servir e glorificar o Santíssimo Coração de Jesus!"
    language_toggle: false
  - id: oracao-009-ladainha-do-sagrado-coracao-de-jesus
    label: Ladainha do Sagrado Coração de Jesus
    prayer: |-
      Senhor, tende piedade de nós.
      Jesus Cristo, tende piedade de nós.
      Senhor, tende piedade de nós.

      Jesus Cristo, ouvi-nos.
      Jesus Cristo, atendei-nos.

      Deus Pai dos céus, tende piedade de nós.
      Deus Filho, Redentor do mundo, tende piedade de nós.
      Deus Espírito Santo, tende piedade de nós.
      Santíssima Trindade, que sois um só Deus, tende piedade de nós.

      Coração de Jesus, Filho do Pai Eterno, tende piedade de nós.
      Coração de Jesus, formado pelo Espírito Santo no seio da Virgem Mãe, tende piedade de nós.
      Coração de Jesus, unido substancialmente ao Verbo de Deus, tende piedade de nós.
      Coração de Jesus, de majestade infinita, tende piedade de nós.
      Coração de Jesus, templo santo de Deus, tende piedade de nós.
      Coração de Jesus, tabernáculo do Altíssimo, tende piedade de nós.
      Coração de Jesus, casa de Deus e porta do céu, tende piedade de nós.
      Coração de Jesus, fornalha ardente de caridade, tende piedade de nós.
      Coração de Jesus, receptáculo de justiça e de amor, tende piedade de nós.
      Coração de Jesus, cheio de bondade e de amor, tende piedade de nós.
      Coração de Jesus, abismo de todas as virtudes, tende piedade de nós.
      Coração de Jesus, digníssimo de todo o louvor, tende piedade de nós.
      Coração de Jesus, Rei e centro de todos os corações, tende piedade de nós.
      Coração de Jesus, no qual estão todos os tesouros da sabedoria e ciência, tende piedade de nós.
      Coração de Jesus, no qual habita toda a plenitude da divindade, tende piedade de nós.
      Coração de Jesus, no qual o Pai põe as suas complacências, tende piedade de nós.
      Coração de Jesus, de cuja plenitude nós todos participamos, tende piedade de nós.
      Coração de Jesus, desejo das colinas eternas, tende piedade de nós.
      Coração de Jesus, paciente e misericordioso, tende piedade de nós.
      Coração de Jesus, rico para todos os que vos invocam, tende piedade de nós.
      Coração de Jesus, fonte de vida e santidade, tende piedade de nós.
      Coração de Jesus, propiciação pelos nossos pecados, tende piedade de nós.
      Coração de Jesus, saturado de opróbrios, tende piedade de nós.
      Coração de Jesus, atribulado por causa de nossos crimes, tende piedade de nós.
      Coração de Jesus, feito obediente até à morte, tende piedade de nós.
      Coração de Jesus, atravessado pela lança, tende piedade de nós.
      Coração de Jesus, fonte de toda a consolação, tende piedade de nós.
      Coração de Jesus, nossa vida e ressurreição, tende piedade de nós.
      Coração de Jesus, nossa paz e reconciliação, tende piedade de nós.
      Coração de Jesus, vítima dos pecadores, tende piedade de nós.
      Coração de Jesus, salvação dos que esperam em vós, tende piedade de nós.
      Coração de Jesus, esperança dos que expiram em vós, tende piedade de nós.
      Coração de Jesus, delícia de todos os santos, tende piedade de nós.

      Cordeiro de Deus, que tirais os pecados do mundo, perdoai-nos, Senhor.
      Cordeiro de Deus, que tirais os pecados do mundo, ouvi-nos, Senhor.
      Cordeiro de Deus, que tirais os pecados do mundo, tende misericórdia de nós.

      V. – Jesus, manso e humilde de Coração.
      R. – Fazei nosso coração segundo semelhante ao vosso.

      OREMOS. Deus onipotente e eterno, olhai para o Coração de vosso Filho diletíssimo e para os louvores e as satisfações que ele, em nome dos pecadores vos tributa; e aos que imploram a vossa misericórdia concedei benigno o perdão em nome do vosso mesmo Filho Jesus Cristo, que convosco vive e reina por todos os séculos dos séculos. Amém.
    prayer-latin: |-
      Kyrie, eléison,
      Christe, eléison,
      Kyrie, eléison,

      Christe, audi nos,
      Christe, exaudi nos,

      Pater de cœlis, Deus, miserere nobis
      Fili Redemptor mundi, Deus, miserere nobis
      Spíritus Sancte, Deus, miserere nobis
      Sancta Trinitas, unus Deus, miserere nobis

      Cor Iesu, Filii Patris æterni, miserére nobis.
      Cor Iesu, in sinu Virginis Matris a Spiritu Sancto formatum, miserére nobis.
      Cor Iesu, Verbo Dei substantialiter unitum, miserére nobis.
      Cor Iesu, maiestatis infinitæ, miserére nobis.
      Cor Iesu, templum Dei sanctum, miserére nobis.
      Cor Iesu, tabernaculum Altissimi, miserére nobis.
      Cor Iesu, domus Dei et porta cæli, miserére nobis.
      Cor Iesu, fornax ardens caritatis, miserére nobis.
      Cor Iesu, iustitiæ et amoris receptaculum, miserére nobis.
      Cor Iesu, bonitate et amore plenum, miserére nobis.
      Cor Iesu, virtutum omnium abyssus, miserére nobis.
      Cor Iesu, omni laude dignissimum, miserére nobis.
      Cor Iesu, rex et centrum omnium cordium, miserére nobis.
      Cor Iesu, in quo sunt omnes thesauri sapientiæ et scientiæ, miserére nobis.
      Cor Iesu, in quo habitat omnis plenitudo divinitatis, miserére nobis.
      Cor Iesu, in quo Pater sibi bene complacuit, miserére nobis.
      Cor Iesu, de cuius plenitude omnes nos accepimus, miserére nobis.
      Cor Iesu, desiderium collium æternorum, miserére nobis.
      Cor Iesu, patiens et multæ misericordiæ, miserére nobis.
      Cor Iesu, dives in omnes qui invocant te, miserére nobis.
      Cor Iesu, fons vitæ et sanctitatis, miserére nobis.
      Cor Iesu, propitiatio pro peccatis nostris, miserére nobis.
      Cor Iesu, saturatum opprobriis, miserére nobis.
      Cor Iesu, attritum propter scelera nostra, miserére nobis.
      Cor Iesu, usque ad mortem obediens factum, miserére nobis.
      Cor Iesu, lancea perforatum, miserére nobis.
      Cor Iesu, fons totius consolationis, miserére nobis.
      Cor Iesu, vita et resurrectio nostra, miserére nobis.
      Cor Iesu, pax et reconciliatio nostra, miserére nobis.
      Cor Iesu, victima peccatorum, miserére nobis.
      Cor Iesu, salus in te sperantium, miserére nobis.
      Cor Iesu, spes in te morientium, miserére nobis.
      Cor Iesu, deliciæ Sanctorum omnium, miserére nobis.

      Agnus Dei, qui tollis peccata mundi, parce nobis, Domine.
      Agnus Dei, qui tollis peccata mundi, exaudi nos, Domine.
      Agnus Dei, qui tollis peccata mundi, miserere nobis

      V. – Iesu, mitis et humilis Corde.
      R. – Fac cor nostrum secundum Cor tuum.

      ORÉMUS. Omnipotens sempiterne Deus, respice in Cor dilectissimi Filii tui, et in laudes et satisfactiones, quas in nomine peccatorum tibi persolvit, iisque misericordiam tuam petentibus, tu veniam concede placatus, in nomine eiusdem Filii tui Iesu Christi, qui tecum vivit et regnat in sæcula sæculorum. Amen.
    language_toggle: true
  - id: oracao-010-consagracao-ao-sagrado-coracao-de-jesus
    label: Consagração ao Sagrado Coração de Jesus
    prayer: |-
      Recebei, Senhor, minha liberdade inteira. Aceitai a memória, a inteligência e a vontade do vosso servo. Tudo o que tenho ou possuo, vós me concedestes, e eu vo-lo restituo e entrego inteiramente à vossa vontade para que o empregueis. Dai-me só vosso amor e vossa graça, e serei bastante rico e nada mais vos solicitarei.

      Doce Coração de Jesus, sede meu amor.
      Doce Coração de Maria, sede a minha salvação.
    language_toggle: false
  - id: oracao-011-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  content: |-
    Oremos por aqueles a quem Deus confiou o cuidado da nossa alma.
  meditation: |-
    ### III PARTE | OS ESPINHOS DO CORAÇÃO DE JESUS Entre os consoladores do Coração de Jesus acham-se primeiramente os zelosos Ministros de Deus e os santos Religiosos e Religiosas

    É o exercito visível de Jesus, são os seus Anjos sobre a terra,

    O fim deles é a gloria de Deus — a honra e gloria de Maria, — a salvação das almas, — o triunfo da Igreja, — numa palavra, todos os interesses de Jesus Cristo. — Cada manhã, na oração, recebem as ordens do seu Deus e Senhor; cada noite dão contas do seu dia… Oh! pedi a Jesus que este exercito se aumente cada vez mais; oferecei-vos, algumas vezes, para quer também vós, sejais alistados no serviço de tão bom Senhor. — Oh! se soubésseis como ali se está bem! como se vive feliz! como se morre cheio de confiança!
---
