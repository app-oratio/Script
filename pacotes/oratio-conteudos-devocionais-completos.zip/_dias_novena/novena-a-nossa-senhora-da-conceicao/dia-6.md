---
title: Dia 6 — Novena a Nossa Senhora da Conceição
devotion: novena-a-nossa-senhora-da-conceicao
day: 6
description: Ó Maria Imaculada, estrela esplendorosa de pureza, alegro-me convosco, porque a vossa Imaculada Conceição foi motivo de grandíssima alegria para todos os anjos do paraíso.
permalink: /novenas/novena-a-nossa-senhora-da-conceicao/dia-6/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 6
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-invocacao-do-espirito-santo
    common_prayer: vinde-espirito-santo
    language_toggle: false
  - id: oracao-003-oracao-inicial
    label: Oração Inicial
    prayer: 'Ó Virgem puríssima concebida sem pecado, desde o primeiro instante toda bela e sem mancha. Ó gloriosa Maria, cheia de graça e Mãe de meu Deus, Rainha dos anjos e dos homens. Humildemente vos venero como Mãe do meu Salvador, que, sendo Deus, me ensinou com sua estima, respeito e submissão a vós a honra e a homenagem que vos devo prestar. Dignai-vos acolher-me a mim, que nesta novena a vós me consagro. Sendo vós refúgio seguro dos pecadores arrependidos, tenho razão para recorrer a vós; sendo Mãe de misericórdia, não podeis não vos compadecer de minha miséria; sendo, depois de Jesus Cristo, toda a minha esperança, não podeis não vos agradar da tenra confiança que em vós tenho. Fazei-me digno de chamar-me vosso filho, a fim de que possa dizer com confiança: Mostrais que sois Mãe.'
    language_toggle: false
  - id: oracao-004-ave-maria
    common_prayer: ave-maria
    language_toggle: false
  - id: oracao-005-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: false
  - id: oracao-006-novena-a-nossa-senhora-da-conceicao
    label: Novena a Nossa Senhora da Conceição
    prayer: Ó Maria Imaculada, estrela esplendorosa de pureza, alegro-me convosco, porque a vossa Imaculada Conceição foi motivo de grandíssima alegria para todos os anjos do paraíso. Dou graças e bendigo à Santíssima Trindade, que vos enriqueceu de tão belo privilégio. Fazei-me entrar um dia nesta alegria e poder, na companhia dos anjos, louvar-vos e bendizer-vos eternamente.
    language_toggle: false
  - id: oracao-007-novena-a-nossa-senhora-da-conceicao
    label: Novena a Nossa Senhora da Conceição
    prayer: |-
      V. Toda bela sois, Maria.
      R. Toda bela sois, Maria.
      V. E sem a mancha original.
      R. E sem a mancha original.
      V. Sois a glória de Jerusalém.
      R. Sois a alegria de Israel.
      V. Sois a honra do nosso povo.
      R. Sois a Advogada dos pecadores.
      V. Ó Maria.
      R. Ó Maria.
      V. Virgem prudentíssima.
      R. Mãe clementíssima.
      V. Rogai por nós.
      R. Intercedei por nós ao Senhor Jesus Cristo.
    language_toggle: false
  - id: oracao-008-novena-a-nossa-senhora-da-conceicao
    label: Novena a Nossa Senhora da Conceição
    prayer: |-
      V. Em vossa Conceição, ó Virgem, fostes imaculada.
      R. Rogai por nós ao Pai cujo Filho destes à luz.

      Oremos. Ó Deus, que pela Imaculada Conceição da Virgem Maria preparastes uma digna morada para o vosso Filho e em atenção aos méritos futuros da morte de Cristo a preservastes de toda mancha, concedei-nos, por sua intercessão, a graça de chegarmos purificados junto de Vós. Ó Deus, pastor e guia de todos os fiéis, olhai propício para o vosso servo N., que constituístes pastor de vossa Igreja; dai-lhe, nós vos pedimos, servir por palavra e exemplo aqueles a quem governa, a fim de alcançar a vida eterna com o rebanho que lhe foi confiado. Ó Deus, nosso refúgio e fortaleza, ouvi as piedosas súplicas de vossa Igreja, Vós que sois o autor da piedade, e concedei-nos alcançar eficazmente o que com confiança vos pedimos. Por Cristo, Senhor nosso. ℟. Amém.
    language_toggle: false
  - id: oracao-009-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
---
