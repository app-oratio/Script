---
title: Dia 1 — Novena a Nossa Senhora das Dores
devotion: novena-a-nossa-senhora-das-dores
day: 1
description: Oh, Virgem dolorosa! Sendo vós árvore florida, fostes tão aflita; e eu, árvore seca e inútil, quero viver sossegado, e sou impaciente a toda moléstia e adversidade.
permalink: /novenas/novena-a-nossa-senhora-das-dores/dia-1/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 1
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-oracao-inicial
    label: Oração Inicial
    prayer: Oh, Virgem! A mais dolorosa do mundo depois de teu Filho, cujas dores estiveste perpetuamente associada, rogo-vos que me alcances fortaleza para sofrer por meus pecados, como vós sofrestes pelos nossos, a fim de que, crucificando minhas paixões e concupiscências na cruz de Cristo, levando-a pelo caminho de minha vida, caminhando em direção ao Senhor e perseverando constantemente ao vosso lado, Mãe minha, ao pé da cruz de vosso Filho, viva sempre e morra contigo, redimido e santificado pelo Sangue preciosíssimo de nosso Redentor. Também vos peço, por vossas dores, que ouças meu pedido nesta Novena e, se convém, concedas-me o que vos peço.
    language_toggle: false
  - id: oracao-003-oracao
    label: Oração
    prayer: Oh, Virgem dolorosa! Sendo vós árvore florida, fostes tão aflita; e eu, árvore seca e inútil, quero viver sossegado, e sou impaciente a toda moléstia e adversidade. Rogo-vos que me concedas espírito de penitência, humildade e mortificação cristã para imitar a vós e a vosso amado Filho, crucificado por mim.
    language_toggle: false
  - id: oracao-004-oracao
    label: Oração
    prayer: 'Lembrai-vos, Virgem Mãe de Deus, quando estiverdes na presença do Senhor, de falar em favor nosso e apartar Sua indignação de nós. Oh, Santíssima Mãe, faz-me esta graça: fixai, em meu coração, com eficácia, as chagas de Jesus crucificado. Fazei que de Cristo em mim leve a morte, que participe de Sua Paixão e sorte e medite em Suas chagas. Para que não arda nos eternos fogos, defendei-me Vós, Oh! Virgem, com teus rogos, no dia do juízo. E Vós, Oh! Cristo, ao sair eu desta vida, por vossa Mãe querida, fazei que chegue à palma de vitória. Quando meu corpo mora, tens que minha alma adquira do paraíso a glória.'
    language_toggle: false
  - id: oracao-005-ave-maria
    common_prayer: ave-maria
    language_toggle: false
    count: 3
  - id: oracao-006-novena-a-nossa-senhora-das-dores
    label: Novena a Nossa Senhora das Dores
    prayer: Rogai por nós, Virgem dolorosíssima, que estivestes constantemente junto à cruz de Jesus Cristo. Nossa Senhora da Boa Morte, rogai por nós!
    language_toggle: false
  - id: oracao-007-oracao-final
    label: Oração Final
    prayer: Oremos. Rogamos-Te, Senhor nosso Jesus Cristo, que interceda ante Tua clemência à bem-aventurada Virgem Maria, Tua Mãe, cuja alma foi atravessada pela espada de dor na hora de Tua Paixão. Pedimos por ti, Oh! Jesus Cristo, Salvador do mundo, que vives e reinas com o Pai e o Espírito Santo pelos séculos dos séculos. Amém
    language_toggle: false
  - id: oracao-008-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
theme: Oração
---
