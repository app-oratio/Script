---
title: Dia 12 — Mês de Maria
devotion: mes-de-nossa-senhora
day: 12
description: Maria me levará ao céu, porque hei de amá-la sempre, invocá-la sempre e sempre servi-la.
permalink: /devocoes-mensais/mes-de-nossa-senhora/dia-12/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 12
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-invocacao-do-espirito-santo
    label: Invocação do Espírito Santo
    prayer: |-
      Vinde, Espírito Santo, enchei os corações dos vossos fiéis e acendei neles o fogo de vosso amor.

      <span style="color: var(--oratio-gold);">℣.</span> Enviai o vosso Espírito e tudo será criado.
      <span style="color: var(--oratio-gold);">℟.</span> E renovareis a face da terra.

      Oremos. Deus, que esclarecestes os corações dos vossos fiéis com as luzes do Espírito Santo, concedei-nos por esse mesmo Espírito conhecer e amar o bem, e gozar sempre de suas divinas consolações. Por Jesus Cristo Nosso Senhor. Amém
    prayer-latin: |-
      Veni, Sancte Spíritus, reple tuórum corda fidélium, et tui amóris in eis ignem accénde.

      <span style="color: var(--oratio-gold);">℣.</span> Emitte Spíritum tuum et creabuntur,
      <span style="color: var(--oratio-gold);">℟.</span> Et renovábis fáciem terra.

      Oremus. Deus, qui corda fidélium Sancti Spiritus ilustratióne docuisti: da nóbis in eódem Spíritu recta sápere, et de ejus semper consolatióne gaudére. Per Christum Dóminum nostrum. Amen
    language_toggle: true
  - id: oracao-003-oracao-inicial
    label: Oração Inicial
    prayer: |-
      Senhor, todo poderoso e infinitamente perfeito, de quem procede todo o ser e para quem todas as criaturas devem sempre se elevar, eu vos consagro este mês e os exercícios de devoção que em cada um de seus dias praticar, oferecendo-os para vossa maior glória em honra de Maria Santíssima. Concedei-me a graça de santificá-lo com piedade, recolhimento e fervor.

      Virgem Santa e Imaculada, minha terna Mãe, volvei para mim vossos olhares tão cheios de doçura e fazei-me sentir cada vez mais os benéficos efeitos de vossa valiosa proteção.

      Anjos do céu, dirigi meus passos, guardai-me à sombra de vossas asas, pondo-me ao abrigo das ciladas do demônio, pedindo por mim a Jesus, Maria e José sua santa bênção. Amém.
    language_toggle: false
  - id: oracao-004-a-devocao-do-terco-recompensada
    label: A devoção do terço recompensada
    prayer: 'Numa pequena cidade da Alsácia morria uma mulher de reconhecida virtude. Era o modelo da mãe de família. A piedade era a alma de sua vida e todas as suas obras: assistia quase todos os dias à santa Missa, recebia muito freqüente a sagrada Comunhão, recitava diariamente o terço e muitas vezes, até em comum: com o marido, os filhos e os criados, se os trabalhos destes o permitiam. Quando esta zelosa serva de Maria caiu em agonia, foi favorecida com uma assinalada graça. Viram-na, de repente, como em êxtase e, arrebatada ao céu, exclamar: Ó meu Jesus! ó eternidade! ó santa Mãe de Deus! ó minha boa Mãe! Tornando a si, muito comovida, disse aos assistentes: Oh que favor! eu não o mereci! Vi Nosso Senhor a me chamar, enchendo-me de alegria indizível o coração. Estava ao lado sua bendita Mãe que mostrou-lhe todos os terços que rezei durante minha vida, que me valerão uma bela coroa eterna. — Morreu pouco depois, e sua morte edificante foi o que deve ser a dos predestinados.'
    language_toggle: false
  - id: oracao-005-ave-maria
    common_prayer: ave-maria
    language_toggle: true
    prayer-latin: Ave Maria, gratia plena, Dominus tecum. Benedicta tu in mulieribus, et benedictus fructus ventris tui, Iesus. Sancta Maria, Mater Dei, ora pro nobis peccatoribus, nunc, et in hora mortis nostræ. Amen.
    count: 3
  - id: oracao-006-composta-por-santo-afonso-de-ligorio
    label: Composta por Santo Afonso de Ligório
    prayer: |-
      Ó Maria, filha predileta do Altíssimo, pudesse eu oferecer-vos e consagrar-vos os meus primeiros anos, como vós vos oferecestes e consagrastes ao Senhor no templo! Mas é já passado esse período de minha vida!

      Todavia, antes começar tarde a vos servir do que ser sempre rebelde. Venho, pois, hoje, oferecer-me a Deus no templo. Sustentai minha fraqueza, e por vossa intercessão alcançai-me de Jesus a graça de lhe ser fiel e a vós até a morte, a fim de que, depois de vos haver servido de todo o coração na vida, participe da glória e da felicidade eterna dos eleitos. Amém.
    language_toggle: false
  - id: oracao-007-ladainha-de-nossa-senhora
    label: Ladainha de Nossa Senhora
    prayer: |-
      Senhor, tende piedade de nós.
      Jesus Cristo, tende piedade de nós.
      Senhor, tende piedade de nós.

      Jesus Cristo, ouvi-nos.
      Jesus Cristo, atendei-nos.

      Deus Pai dos céus, tende piedade de nós.
      Deus Filho, Redentor do mundo, tende piedade de nós.
      Deus Espírito Santo, tende piedade de nós.
      Santíssima Trindade, que sois um só Deus, tende piedade de nós.

      Santa Maria, rogai por nós.
      Santa Mãe de Deus, rogai por nós.
      Santa Virgem das virgens, rogai por nós.
      Mãe de Jesus Cristo, rogai por nós.
      Mãe da divina graça, rogai por nós.
      Mãe puríssima, rogai por nós.
      Mãe castíssima, rogai por nós.
      Mãe imaculada, rogai por nós.
      Mãe intacta, rogai por nós.
      Mãe amável, rogai por nós.
      Mãe admirável, rogai por nós.
      Mãe do bom conselho, rogai por nós.
      Mãe do Criador, rogai por nós.
      Mãe do Salvador, rogai por nós.
      Virgem prudentíssima, rogai por nós.
      Virgem venerável, rogai por nós.
      Virgem louvável, rogai por nós.
      Virgem poderosa, rogai por nós.
      Virgem benigna, rogai por nós.
      Virgem fiel, rogai por nós.
      Espelho de justiça, rogai por nós.
      Templo da sabedoria, rogai por nós.
      Causa da nossa alegria, rogai por nós.
      Vaso espiritual, rogai por nós.
      Vaso honorífico, rogai por nós.
      Vaso insigne de devoção, rogai por nós.
      Rosa mística, rogai por nós.
      Torre de Davi, rogai por nós.
      Torre de marfim, rogai por nós.
      Casa de ouro, rogai por nós.
      Arca d’aliança, rogai por nós.
      Porta do céu, rogai por nós.
      Estrela da manhã, rogai por nós.
      Saúde dos enfermos, rogai por nós.
      Refúgio dos pecadores, rogai por nós.
      Consoladora dos aflitos, rogai por nós.
      Auxílio dos cristãos, rogai por nós.
      Rainha dos anjos, rogai por nós.
      Rainha dos patriarcas, rogai por nós.
      Rainha dos Profetas, rogai por nós.
      Rainha dos apóstolos, rogai por nós.
      Rainha dos mártires, rogai por nós.
      Rainha dos confessores, rogai por nós.
      Rainha das virgens, rogai por nós.
      Rainha de todos os santos, rogai por nós.
      Rainha concebida sem pecado original, rogai por nós.
      Rainha assunta ao céu, rogai por nós.
      Rainha do sacratíssimo Rosário, rogai por nós.
      Rainha da paz, rogai por nós.

      Cordeiro de Deus, que tirais os pecados do mundo, perdoai-nos, Senhor.
      Cordeiro de Deus, que tirais os pecados do mundo, ouvi-nos, Senhor.
      Cordeiro de Deus, que tirais os pecados do mundo, tende misericórdia de nós.

      <span style="color: var(--oratio-gold);">℣.</span> Rogai por nós, Santa Mãe de Deus.
      <span style="color: var(--oratio-gold);">℟.</span> Para que sejamos dignos das promessas de Cristo.

      Oremos. Senhor Deus, nós Vos suplicamos que concedais aos vossos servos perpétua saúde de alma e de corpo; e que, pela gloriosa intercessão da bem-aventurada sempre Virgem Maria, sejamos sempre livres da tristeza do século e gozemos da eterna alegria. Por Cristo, nosso Senhor. Amém.
    prayer-latin: "Kyrie, eléison,\nChriste, eléison,\nKyrie, eléison,\n\nChriste, audi nos,\nChriste, exaudi nos,\n\nPater de cœlis, Deus, miserere nobis\nFili Redemptor mundi, Deus, miserere nobis\nSpíritus Sancte, Deus, miserere nobis\nSancta Trinitas, unus Deus, miserere nobis\n\nSancta Maria, ora pro nobis\nSancta Dei Genitrix, ora pro nobis\nSancta Virgo vírginum, ora pro nobis\nMater Christi, ora pro nobis\nMater Divinæ Gratiæ, ora pro nobis\nMater puríssima, ora pro nobis\nMater castíssima, ora pro nobis\nMater inviolata, ora pro nobis\nMater intemerata, ora pro nobis\nMater amábilis, ora pro nobis\nMater admirábilis, ora pro nobis\nMater boni consilii, ora pro nobis\nMater Creatóris, ora pro nobis\nMater Salvatóris, ora pro nobis\nVirgo prudentíssima, ora pro nobis\nVirgo veneranda, ora pro nobis\nVirgo prædicanda, ora pro nobis\nVirgo potens, ora pro nobis\nVirgo clemens, ora pro nobis\nVirgo Fidelis, ora pro nobis\nSpeculum justitiæ, ora pro nobis\nSedes sapientiæ, ora pro nobis\n\
      Causa nostræ laetitiæ, ora pro nobis\nVas spirituale, ora pro nobis\nVas honorabile, ora pro nobis\nVas insigne devotionis, ora pro nobis\nRosa mystica, ora pro nobis\nTurris Davidica, ora pro nobis\nTurris eburnea, ora pro nobis\nDomus áurea, ora pro nobis\nFœderis arca, ora pro nobis\nJanua cœli, ora pro nobis\nStella matutina, ora pro nobis\nSalus infirmorum, ora pro nobis\nRefugium peccatorum, ora pro nobis\nConsolatrix afflictorum, ora pro nobis\nAuxilium christianorum, ora pro nobis\nRegina angelórum, ora pro nobis\nRegina patriarcharum, ora pro nobis\nRegina prophetarum, ora pro nobis\nRegina apostolórum, ora pro nobis\nRegina martyrum, ora pro nobis\nRegina confessórum, ora pro nobis\nRegina virginum, ora pro nobis\nRegina sanctorum omnium, ora pro nobis\nRegina sine labe originali concepta, ora pro nobis\nRegina in cœlum assumpta, ora pro nobis\nRegina sacratíssimi Rosarii, ora pro nobis\nRegina pacis, ora pro nobis\n\nAgnus Dei, qui tollis peccata mundi, parce nobis, Domine.\
      \ \nAgnus Dei, qui tollis peccata mundi, exaudi nos, Domine.\nAgnus Dei, qui tollis peccata mundi, miserere nobis\n\n<span style=\"color: var(--oratio-gold);\">℣.</span> Ora pro nobis sancta Dei Genitrix.\n<span style=\"color: var(--oratio-gold);\">℟.</span> Ut digni efficiamur promissionibus Christi.\n\nOrémus. Concéde nos fámulos tuos, quæsumus, Dómine Deus, perpétua mentis et córporis sanitáte gaudére: et gloriósa beátæ Maríæ semper Vírginis intercessióne, a præsénti liberári tristítia, et ætérna pérfrui lætítia. Per Christum Dóminum nostrum. Amen."
    language_toggle: true
  - id: oracao-008-oracao
    label: Oração
    prayer: |-
      <b>Regina Caeli</b> <span style="color: var(--oratio-gold);">*</span>

      <span style="color: var(--oratio-gold);">*</span> Para o Tempo Pascal

      <span style="color: var(--oratio-gold);">℣.</span> Rainha do céu, alegrai-vos, aleluia!
      <span style="color: var(--oratio-gold);">℟.</span> Porque quem merecestes trazer em vosso seio, aleluia!
      <span style="color: var(--oratio-gold);">℣.</span> Ressuscitou como disse, aleluia!
      <span style="color: var(--oratio-gold);">℟.</span> Rogai a Deus por nós, aleluia!
      <span style="color: var(--oratio-gold);">℣.</span> Exultai e alegrai-vos, Virgem Maria, aleluia!
      <span style="color: var(--oratio-gold);">℟.</span> Porque o Senhor ressuscitou verdadeiramente, aleluia!

      Oremos. Ó Deus, que dignastes alegrar o mundo com a ressurreição do vosso filho Jesus Cristo, nosso Senhor, concedei-nos, vos suplicamos, que por sua mãe, a Virgem Maria, alcancemos as alegrias da vida eterna. Por Jesus Cristo, nosso Senhor. Amém


      <b>Ave Maris Stella</b> <span style="color: var(--oratio-gold);">*</span>

      <span style="color: var(--oratio-gold);">*</span> Para os outros tempos Litúrgicos

      Ave, do mar Estrela
      De Deus mãe bela,
      Sempre virgem, da morada
      Celeste Feliz entrada.

      Ó tu que ouviste da boca
      Do anjo a saudação;
      Dá-nos a paz e quietação;
      E o nome da Eva troca.

      As prisões aos réus desata.
      E a nós cegos alumia;
      De tudo que nos maltrata
      Nos livra, o bem nos granjeia.

      Ostenta que és mãe, fazendo
      Que os rogos do povo seu
      Ouça aquele que, nascendo
      Por nós, quis ser filho teu.

      Ó virgem especiosa,
      Toda cheia de ternura,
      Extintos nossos pecados
      Dá-nos pureza e bravura,

      Dá-nos uma vida pura,
      Põe-nos em vida segura,
      Para que a Jesus gozemos,
      E sempre nos alegremos.

      A Deus Pai veneremos:
      A Jesus Cristo também:
      E ao Espírito Santo; demos
      Aos três um louvor: Amém.
    prayer-latin: |-
      <b>Regina Caeli</b> <span style="color: var(--oratio-gold);">*</span>

      <span style="color: var(--oratio-gold);">*</span> Para o Tempo Pascal

      <span style="color: var(--oratio-gold);">℣.</span> Regina cœli, lætare, allelúia.
      <span style="color: var(--oratio-gold);">℟.</span> Quia quem meruisti portáre, allelúia,
      <span style="color: var(--oratio-gold);"*>℣.</span> Resurréxit, sicut dixit, allelúia.
      <span style="color: var(--oratio-gold);">℟.</span> Ora pro nobis Deum, allelúia.
      <span style="color: var(--oratio-gold);">℣.</span> Gaude et lætáre, Virgo Maria, allelúia.
      <span style="color: var(--oratio-gold);">℟.</span> Quia surréxit Dóminus vere, allelúia.

      Oremus: Deus, qui per resurrectionem Filii tui, Domini nostri Jesu Christi, mundum lætificare dignatus es: præsta, quæsumus; ut per ejus Genetricem Virginem Mariam, perpetuæ capiamus gaudia vitæ. Per eumdem Christum Dominum nostrum. Amen


      <b>Ave Maris Stella</b> <span style="color: var(--oratio-gold);">*</span>

      <span style="color: var(--oratio-gold);">*</span> Para os outros tempos Litúrgicos

      Ave, Maris Stella,
      Dei mater alma,
      Atque semper Virgo,
      Felix caeli porta.

      Sumens illud Ave,
      Gabrielis ore,
      Funda nos in pace
      Mutans Evae nomen.

      Solve vincla reis,
      Profer lumen caecis,
      Mala nostra pelle,
      Bona cuncta posce.

      Monstra te esse Matrem,
      Sumat per te preces,
      Qui pro nobis natus
      Tulit esse tuus.

      Virgo singularis,
      Inter omnes mitis,
      Nos, culpis solutos,
      Mites fac et castos.

      Vitam praesta puram,
      Iter para tutum:
      Ut, videntes Jesum,
      Semper collaetemur.

      Sit laus Deo Patri,
      Summo Christo decus
      Spiritui Sancto,
      Tribus honor unus. Amén.
    language_toggle: true
  - id: oracao-009-lembrai-vos
    label: Lembrai-vos
    prayer: Lembrai-vos, ó Piíssima Virgem Maria, de que nunca se ouviu dizer, que algum daqueles que tenha recorrido à vossa clemência, implorado a vossa assistência, reclamado o vosso socorro, fosse por vós abandonado. Animado eu, pois, com igual confiança, a vós, Virgem das Virgens, como Mãe recorro, de vós me valho e gemendo sob o peso de meus pecados, me prostro a vossos pés. Não desprezeis as minhas súplicas, ó mãe do Verbo de Deus humanado, mas dignai-vos de as ouvir propícia e de me alcançar o que vos rogo.  Amém.
    prayer-latin: Memorare, o piisima Virgo Maria, non esse auditum a saeculo, quemquam ad tua currentem praesidia, tua implorantem auxilia, tua petentem suffragia esse derelicta. Nos tali animati confidentia ad te, Virgo Virginum, Mater, currimus; ad te venimus; coram te gementes peccatores assistimus. Noli, Mater Verbi, verba nostra despicere, sed audi propitia et exaudi.  Amen.
    language_toggle: true
  - id: oracao-010-jaculatoria
    label: Jaculatória
    prayer: Ó Maria, concebida sem pecado, rogai por nós que recorremos a vós. (3x)
    language_toggle: false
    count: 3
  - id: oracao-011-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  meditation: |-
    ### Maria me levará ao céu - I

    Maria me levará ao céu, porque hei de amá-la sempre, invocá-la sempre e sempre servi-la.

    I. Hei de amá-la sempre. Amar é ter por uma pessoa um  sentimento que nos impele para ela que faz pensar voluntariamente nela, que induz a procurar contentá-la e ser-lhe agradável — sentimento esse que incomoda, quando, voluntária ou mesmo involuntariamente, se lhe tem desagradado.

    Este sentimento, eu o tenho para com a Virgem Maria. Deus, tão bom, permitiu que, desde a mais tenra infância, nascesse este afeto em meu coração; ele cresceu, e até quando eu ofendia a Deus, esse amor, por uma graça tão particular, não se enfraqueceu, e foi ele que me reconduziu ao dever.

    A natureza de todo sentimento, eu o sei, é ser móvel, variar, extinguir-se; mas, o que experimento por Maria não há de variar, nem extinguir nunca porque:

    II. Hei de orar sempre a Maria. A oração é o alimento do amor sobrenatural; a oração é o entretenimento cotidiano com a Virgem Maria, é o recurso à proteção divina pela intercessão de Maria para não pecar ou para sair do pecado; a oração é o meio infalível para obter a graça, para vencer a tentação, para ter a vontade e a força de cumprir o dever.

    Maria, quero me habituar a recitar cotidianamente uma oração particular em vossa honra. Prometo-o com toda força de vontade de que sou capaz. Sim, todos os dias hei de recitar ou uma parte do terço, devoção tão atraente quando se tem o coração puro; ou o “Lembrai-vos”, tão consolador na aflição; ou a invocação: ó minha Soberana, ó minha.

    Mãe — tão poderosa nas tentações… E estas orações servirão para nutrir em minha alma o amor que vos tenho.
theme: Maria me levará ao céu - I
---
