---
title: Dia 9 — Novena a Santa Maria Goretti
devotion: novena-a-santa-maria-goretti
day: 9
description: Santa Maria Goretti, o Senhor vos fez o grande dom de serdes liberta do pecado e do poder do mal na alma e no corpo… até a sacrificar vossa vida; vós que gritastes para Alessandro; “Que fazes, Alessandro?
permalink: /novenas/novena-a-santa-maria-goretti/dia-9/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 9
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-novena-a-santa-maria-goretti
    label: Novena a Santa Maria Goretti
    prayer: Meu Deus, vinde em meu auxílio. Senhor, apressai-vos em me socorrer.
    language_toggle: false
  - id: oracao-003-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: false
  - id: oracao-004-oracao-inicial
    label: Oração Inicial
    prayer: Vinde, Espírito Santo e enviai do céu um raio de Vossa luz. Vinde, Pai dos pobres, vinde, distribuidor dos bens, vinde luz dos corações. Consolador ótimo, doce hóspede das almas e suave refrigério. Nos trabalhos sois o repouso, no calor o frescor, nas lágrimas a consolação. Ó luz beatíssima, inflamai o íntimo dos corações dos Vossos fiéis. Sem a Vossa graça nada há no homem, nada de inocente. Lavai o que é sórdido, regai o que é seco, sarai quem está ferido. Dobrai o que é duro, abrasai o que é frio e reconduzi o desviado. Concedei aos Vossos servos, que em Vós confiam, os sete dons sagrados. Dai-lhes o mérito das virtudes, o êxito da salvação e a alegria perene.
    language_toggle: false
  - id: oracao-005-oracao
    label: Oração
    prayer: 'Santa Maria Goretti, o Senhor vos fez o grande dom de serdes liberta do pecado e do poder do mal na alma e no corpo… até a sacrificar vossa vida; vós que gritastes para Alessandro; “Que fazes, Alessandro? Tu vais para o inferno”… livrai a mim, aos meus, à Santa Igreja de Deus, a humanidade inteira, com o poder de Deus: – dos pecados: a fonte e origem de todo o mal; – dos males físicos e morais; – das neuroses e depressões; – de qualquer forma de inferioridade e de superioridade; – das blasfêmias; – dos vícios de capital e de toda sugestão do maligno.'
    language_toggle: false
  - id: oracao-006-oracao-final
    label: Oração Final
    prayer: Em particular, Santa Maria Goretti, alcançai-me esta graça (fazer o pedido) que tanto desejo, desde que seja conforme a santa vontade de Deus; que dê frutos de amor, de caridade, de paz; livrai-me do egoísmo; fazei-me colaborador na difusão do Reino de Deus no mundo. Amém.
    language_toggle: false
  - id: oracao-007-pai-nosso
    common_prayer: pai-nosso
    language_toggle: false
  - id: oracao-008-ave-maria
    common_prayer: ave-maria
    language_toggle: false
  - id: oracao-009-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: false
  - id: oracao-010-novena-a-santa-maria-goretti
    label: Novena a Santa Maria Goretti
    prayer: Santa Maria Goretti, rogai por nós.
    language_toggle: false
  - id: oracao-011-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
theme: Oração
---
