---
title: Dia 2 — Novena à Santa Mônica
devotion: novena-a-santa-monica
day: 2
description: Ó Deus de infinita glória e majestade! Que inefável vos comprazíeis nos sentimentos de piedade e devoção com que vos amava e servia vossa fidelíssima serva Santa Mônica, quando com tanto gosto preferia as delícias…
permalink: /novenas/novena-a-santa-monica/dia-2/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 2
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-ato-de-contricao
    label: Ato de Contrição
    prayer: Meu Senhor Jesus Cristo, divino Redentor e Salvador das almas, que por mediação das piedosas lágrimas de vossa serva Mônica, dignastes-Vos converter inteiramente o coração de seu filho Agostinho, e desde o dia de sua total e ditosa conversão lhe inspirastes que fizesse sempre frutos de verdadeira penitência; pelas lágrimas benditas daquela mãe, e pela mais profunda e sincera conversão daquele bem-aventurado filho, concedei, misericordioso, a nossas almas, aquela dor de verdadeiro arrependimento, que atinge com segurança o perdão de toda culpa; aquele pranto de sincero arrependimento que apaga toda iniqüidade e toda mancha. E ao fazer tais frutos de verdadeira penitência, que devolvam a justificativa e a paz a nosso espírito contrito e humilhado, que deverá se converter e desejar ver-Vos glorioso para sempre. Amém.
    language_toggle: false
  - id: oracao-003-oracao-inicial
    label: Oração Inicial
    prayer: Ó gloriosa Santa Mônica, espelho de esposas, modelo de mães, consolo de viúvas, mulher admirável, a quem Deus infundiu o espírito de oração e concedeu aquele dom de lágrimas com que soubestes fazer violência ao Deus das misericórdias, para que se compadecesse de vossos gemidos, escutasse vossas preces e vos concedesse as vossas suplicas, nós que sofremos e choramos nos tristes caminhos da vida, a suplicar-vos que nos atinjais o espírito de oração que tivestes e a misericórdia que merecem nossas culpas, para que derramando com humildade nosso coração diante de Deus de toda piedade e misericórdia, atinjamos a graça de viver a santa vida que vivestes na terra, e mereçamos a glória que gozais agora no céu, em companhia de nossos pais, esposos e filhos, e de todos os que pelo sangue e pelo afeto nos pertencem e são, em Jesus Cristo, Senhor nosso, amados e queridos de nosso coração. Amém.
    language_toggle: false
  - id: oracao-004-segundo-dia-devocao
    label: 'Segundo dia: Devoção'
    prayer: Ó Deus de infinita glória e majestade! Que inefável vos comprazíeis nos sentimentos de piedade e devoção com que vos amava e servia vossa fidelíssima serva Santa Mônica, quando com tanto gosto preferia as delícias secretas da oração e do recolhimento às ternas carícias dos seus e, a todos os afagos sedutores da carne; concedei-me, pela intercessão desta vossa serva devotíssima, a graça de que eu vos ame e vos sirva sem pecado até a morte, e que prefira sempre a dita de agradar-vos, a todas as vaidades e deleites da terra, e assim mereça desfrutar num dia as eternas e puríssimas delícias da glória. Amém.
    language_toggle: false
  - id: oracao-005-pai-nosso
    common_prayer: pai-nosso
    language_toggle: false
  - id: oracao-006-ave-maria
    common_prayer: ave-maria
    language_toggle: false
  - id: oracao-007-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: false
  - id: oracao-008-pedido
    label: Pedido
    prayer: Neste momento, pede-se a graça que deseja alcançar por intercessão da bem-aventurada Santa Mônica.
    language_toggle: false
  - id: oracao-009-preces
    label: Preces
    prayer: |-
      Ó Senhor, que confortastes a Mônica em suas provas, confortai a quantos sofrem de solidão e abandono em nossa sociedade, roguemos ao Senhor.

      Ó Senhor, que trocastes em gozo as lágrimas de Mônica, concedei-nos que jamais contristemos a ninguém, senão que mais bem sejamos causa de alegria para nossos irmãos, roguemos ao Senhor.

      Ó Senhor, que confortastes a Mônica em suas orações pela conversão de seu filho, ajudai-nos a não desesperar no tempo de prova, senão a pôr nele toda nossa esperança, roguemos ao Senhor.

      Ó Senhor, que concedestes a Santa Mônica superar com fortaleza as dificuldades de seu matrimônio, concedei-nos a todos os cônjuges que têm dificuldades, que saibam oferecer-se mutuamente consolo, roguemos ao Senhor.

      Ó Senhor, que quisestes que Santa Mônica fosse modelo de virtudes na vida familiar, olhai a todas as mães do mundo, para que sempre saibam conduzir a seus filhos para vós, roguemos ao Senhor.

      Ó Senhor, nossa mãe Santa Mônica que, em seu leito de morte, pedira aos seus que a recordassem diante de vosso altar, aceitai as orações de nossas comunidades por nossos irmãos e irmãs falecidos, roguemos ao Senhor.
    language_toggle: false
  - id: oracao-010-aclamacoes
    label: Aclamações
    prayer: |-
      Com vossas lágrimas de amor,
      Mãe do grande Agostinho,
      destes à Igreja um Doutor,
      destes ao céu um serafim.
      Salve a vós, mulher bendita,
      muda e só em vosso quebranto,
      que pressagiastes com vosso pranto
      novos triunfos da Cruz!
      Cada lágrima que rola
      por vosso pálido semblante
      é um reflexo radiante
      do sol da eterna luz.
      Com vossas lágrimas de amor…
      Como solo lamentador
      de tortura solitária,
      suba ao céu vossa prece
      do vale da dor;
      Deus vos escuta, e os vossos frutos,
      do poder de Deus,
      cai um gigante rendido:
      e é o filho de vosso amor!
      Com vossas lágrimas de amor.
    language_toggle: false
  - id: oracao-011-oracao-final
    label: Oração Final
    prayer: Gloriosíssima e bem-aventurada, Santa Mônica! Grande na paciência, magnânima na esperança e ditosa no triunfo; mulher sábia e prudente, que soubestes edificar vossa casa e nela resplandecestes como o sol quando amanhece nas alturas do céu, e em tudo fostes exemplo esclarecido à mulher cristã; agora que estais já na “terra dos que vivem para sempre, onde não há prantos nem gemidos, nem dor algum”, lembrai-vos das que ainda gememos e choramos neste vale, onde gemestes e chorastes; e intercedei diante do Senhor para que tenha compaixão de tantas mães e esposas em suas tribulações e trabalhos, e para que recolha nossos gemidos e escute nossas preces e nos conceda, como a vós, o fim de todos nossos desejos, e mereçamos, num dia, reinar e descansar na glória como vós, rodeadas de todos os entes queridos de nosso coração, e abençoar, ali, convosco as eternas misericórdias do Senhor, pelos séculos dos séculos. Amém.
    language_toggle: false
  - id: oracao-012-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
theme: 'Segundo dia: Devoção'
---
