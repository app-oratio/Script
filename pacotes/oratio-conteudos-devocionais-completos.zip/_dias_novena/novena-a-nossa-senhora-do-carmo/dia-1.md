---
title: Dia 1 — Novena a Nossa Senhora do Carmo
devotion: novena-a-nossa-senhora-do-carmo
day: 1
description: Consideremos como desde o princípio da Santa Igreja, Maria Santíssima se reconheceu nossa advogada e nossa Mãe.
permalink: /novenas/novena-a-nossa-senhora-do-carmo/dia-1/
default_language: pt
language_toggle: false
sequence_title: Orações do dia 1
search: false
sections:
- id: secao-01-oracoes
  title: Orações
  prayers:
  - id: oracao-001-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  - id: oracao-002-oracao-inicial
    label: Oração Inicial
    prayer: 'Sacratíssima Senhora, Mãe de Deus, à qual Nosso Senhor desde a Sua cruz destinou para nossa advogada e Mãe, vós vedes desde o Céu as tribulações em que se acham vossos filhos, os pecadores, neste mundo, vale de lágrimas e misérias, e que pela maior parte nos achamos rodeados de furiosos inimigos, o mundo, o Demônio, e a carne, e como quase sempre sucumbimos nas batalhas que continuamente nos dão. Compadecei-vos de nós, ó Senhora. Vós sois a que em diversas épocas tendes prestado auxílio ao vosso povo. Vossa é a instituição do santo escapulário do Carmo: Vós mesma o destes ao Bem-aventurado Simão carmelita para que, por este celeste vestido, fossem conhecidos os vossos servos especiais. Felizmente, chegou até nós esta santa e tão interessante devoção. Reconhecei-nos por vossos, ó Santíssima Virgem. Também nós nos achamos honrados com esta libré vossa, e em honra deste especial benefício, queremos celebrar a vossa festa, antecipada por nove dias em vossa honra. Olhai para nós,
      Senhora, e lançai-nos uma benção de amorosa Mãe, para que no fim desta novena fique mais honrado vosso Filho, e nós, mais aproveitados e fervorosos na vossa devoção. Amém.'
    language_toggle: false
  - id: oracao-003-pai-nosso
    common_prayer: pai-nosso
    language_toggle: false
    count: 3
  - id: oracao-004-ave-maria
    common_prayer: ave-maria
    language_toggle: false
    count: 3
  - id: oracao-005-gloria-ao-pai
    common_prayer: gloria-ao-pai
    language_toggle: false
    count: 3
  - id: oracao-006-novena-a-nossa-senhora-do-carmo
    label: Novena a Nossa Senhora do Carmo
    prayer: |-
      V. Mãe e Senhora dos carmelitas.
      R. Olhai para nossas almas aflitas.
    language_toggle: false
  - id: oracao-007-novena-a-nossa-senhora-do-carmo
    label: Novena a Nossa Senhora do Carmo
    prayer: |-
      V. Rogai por nós, Santa Mãe de Deus.
      R. Para que sejamos dignos das promessas de Cristo.

      Em latim:

      V. Ora pro nobis, Sancta Dei Génitrix.
      R. Ut digni efficiámur promissiónibus Christi.
    language_toggle: false
  - id: oracao-008-oracao
    label: Oração
    prayer: "Oremus: Ó Deus, que destes à Ordem do Carmelo a glória insigne de ter o nome da Virgem Santíssima, vossa Mãe, fazei por vossa misericórdia que, fortalecidos com a proteção daquela cuja memória hoje celebramos, mereçamos alcançar a felicidade eterna. Que viveis e reinais, por todos os séculos dos séculos. Amém.\n\nEm latim: \n\nOremus: Deus, qui beatíssimae semper Vírginis et Genitrícis tuae Maríae singulári título Carméli Ordinem decorásti: concéde propítius; ut cujus hódie commemoratiónem solémni celebrámus, ejus muníti praesídiis, ad gáudia sempitérna perveníre mereámur. Qui vivis et regnas in saécula saeculórum."
    language_toggle: false
  - id: oracao-009-sinal-da-cruz
    common_prayer: sinal-da-cruz
    language_toggle: false
  meditation: |-
    ### Meditação

    Consideremos como desde o princípio da Santa Igreja, Maria Santíssima se reconheceu nossa advogada e nossa Mãe. Já ela acompanhou os Apóstolos e os discípulos, desde que, juntos, no Cenáculo, esperavam a vinda do divino Espírito:; já ela como que fazia as vezes do seu Filho: nas tribulações dos fiéis é natural que a ela recorressem, e ouvissem aquele divino oráculo, e se guiassem por suas palavras e por seus tão santos e acertados conselhos. Oh, se ainda hoje nós imitássemos a prática da primitiva Igreja, e recorrêssemos à Senhora em todas as nossas necessidades, outro seria então o nosso aproveitamento.
theme: Meditação
---
